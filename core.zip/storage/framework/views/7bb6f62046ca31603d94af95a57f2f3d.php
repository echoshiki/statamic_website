<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Create Taxonomy')); ?>

<?php $__env->startSection('content'); ?>

    <taxonomy-create-form
        route="<?php echo e(cp_route('taxonomies.store')); ?>">
    </taxonomy-create-form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/taxonomies/create.blade.php ENDPATH**/ ?>