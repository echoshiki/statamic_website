<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Create Navigation')); ?>

<?php $__env->startSection('content'); ?>
    <navigation-create-form
        route="<?php echo e(cp_route('navigation.store')); ?>">
    </navigation-create-form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/navigation/create.blade.php ENDPATH**/ ?>