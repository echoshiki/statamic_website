<?php
use function Statamic\trans as __;
$authed = \Statamic\Facades\User::current();
?>



<?php $__env->startSection('content'); ?>
    <div class="min-h-screen flex justify-center <?php echo e($authed ? 'pt-30' : 'items-center'); ?>">
        <h1 class="text-3xl tracking-tighter mb-10 opacity-50 text-center"><?php echo e(__('Page Not Found')); ?></h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($authed ? 'statamic::layout' : 'statamic::outside', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/errors/404.blade.php ENDPATH**/ ?>