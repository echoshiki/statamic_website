<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', Statamic::crumb($taxonomy->title(), 'Taxonomies')); ?>

<?php $__env->startSection('content'); ?>

<header class="mb-6">
    <?php echo $__env->make('statamic::partials.breadcrumb', [
        'url' => cp_route('taxonomies.index'),
        'title' => __('Taxonomies')
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <h1 v-pre><?php echo e(__($taxonomy->title())); ?></h1>
</header>

<div class="card p-4 content">
    <div class="flex flex-wrap">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $taxonomy)): ?>
        <a href="<?php echo e(cp_route('taxonomies.edit', $taxonomy->handle())); ?>" class="w-full lg:w-1/2 p-4 flex items-start hover:bg-gray-200 dark:hover:bg-dark-550 rounded-md group">
            <div class="h-8 w-8 rtl:ml-4 ltr:mr-4 text-gray-800 dark:text-dark-175">
                <?php echo Statamic::svg('icons/light/hammer-wrench') ?>
            </div>
            <div class="flex-1 mb-4 md:mb-0 rtl:md:ml-6 ltr:md:mr-6">
                <h3 class="mb-2 text-blue dark:text-blue-600"><?php echo e(__('Configure Taxonomy')); ?> <?php echo Statamic::cpDirection() === 'ltr' ? '&rarr;' : '&larr;' ?></h3>
                <p><?php echo e(__('statamic::messages.taxonomy_next_steps_configure_description')); ?></p>
            </div>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', ['Statamic\Contracts\Taxonomies\Term', $taxonomy, \Statamic\Facades\Site::get($site)])): ?>
        <a href="<?php echo e(cp_route('taxonomies.terms.create', [$taxonomy->handle(), $site])); ?>" class="w-full lg:w-1/2 p-4 flex items-start hover:bg-gray-200 dark:hover:bg-dark-550 rounded-md group">
            <div class="h-8 w-8 rtl:ml-4 ltr:mr-4 text-gray-800 dark:text-dark-175">
                <?php echo Statamic::svg('icons/light/content-writing') ?>
            </div>
            <div class="flex-1 mb-4 md:mb-0 rtl:md:ml-6 ltr:md:mr-6">
                <h3 class="mb-2 text-blue dark:text-blue-600"><?php echo e(__('Create Term')); ?> <?php echo Statamic::cpDirection() === 'ltr' ? '&rarr;' : '&larr;' ?></h3>
                <p><?php echo e(__('statamic::messages.taxonomy_next_steps_create_term_description')); ?></p>
            </div>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configure fields')): ?>
        <a href="<?php echo e(cp_route('taxonomies.blueprints.index', $taxonomy->handle())); ?>" class="w-full lg:w-1/2 p-4 flex items-start hover:bg-gray-200 dark:hover:bg-dark-550 rounded-md group">
            <div class="h-8 w-8 rtl:ml-4 ltr:mr-4 text-gray-800 dark:text-dark-175">
                <?php echo Statamic::svg('icons/light/blueprint') ?>
            </div>
            <div class="flex-1 mb-4 md:mb-0 rtl:md:ml-6 ltr:md:mr-6">
                <h3 class="mb-2 text-blue dark:text-blue-600"><?php echo e(__('Configure Blueprints')); ?> <?php echo Statamic::cpDirection() === 'ltr' ? '&rarr;' : '&larr;' ?></h3>
                <p><?php echo e(__('statamic::messages.taxonomy_next_steps_blueprints_description')); ?></p>
            </div>
        </a>
        <?php endif; ?>
        <div class="hidden first:flex justify-center items-center p-8 w-full">
            <?php echo Statamic::svg($svg ?? 'empty/content') ?>
        </div>
    </div>
</div>
<?php echo $__env->make('statamic::partials.docs-callout', [
    'topic' => __('Taxonomies'),
    'url' => Statamic::docsUrl('taxonomies')
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/taxonomies/empty.blade.php ENDPATH**/ ?>