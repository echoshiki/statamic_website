<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Scaffold Collection')); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-6">
        <?php echo $__env->make('statamic::partials.breadcrumb', [
            'url' => cp_route('collections.show', $collection->handle()),
            'title' => $collection->title()
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <h1> <?php echo e(__('Scaffold Views')); ?></h1>
    </header>

    <collection-scaffolder
        title="<?php echo e($collection->title()); ?>"
        handle="<?php echo e($collection->handle()); ?>"
        route="<?php echo e(url()->current()); ?>" >
    </collection-scaffolder>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/collections/scaffold.blade.php ENDPATH**/ ?>