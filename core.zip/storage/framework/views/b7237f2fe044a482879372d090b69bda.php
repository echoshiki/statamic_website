<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Create Form')); ?>

<?php $__env->startSection('content'); ?>
    <form-create-form
        route="<?php echo e(cp_route('forms.store')); ?>">
    </form-create-form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/forms/create.blade.php ENDPATH**/ ?>