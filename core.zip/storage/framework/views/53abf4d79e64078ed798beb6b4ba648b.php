<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Updater')); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('statamic::partials.breadcrumb', [
        'url' => cp_route('updater'),
        'title' => __('Updates')
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <updater slug="<?php echo e($slug); ?>" package="<?php echo e($package); ?>" name="<?php echo e($name); ?>"></updater>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/statamic_website/vendor/statamic/cms/src/Providers/../../resources/views/updater/show.blade.php ENDPATH**/ ?>