<?php

return [

    'unique_entry_value' => 'The :attribute has already been taken.',
    'unique_user_value' => 'The :attribute has already been taken.',

];
